# TryxzObf — Netlify + Obscura

La web estática se publica en Netlify. El motor Python Obscura se ejecuta en un backend Flask alojado por separado (Render). Netlify por sí solo no ejecuta `main.py`.

## 1. Publicar el backend en Render
1. Sube esta carpeta del proyecto a un repositorio GitHub.
2. En Render, crea un **Blueprint** usando ese repositorio y selecciona `backend/render.yaml`.
3. Espera a que termine el despliegue. Copia la URL del servicio, por ejemplo `https://tryxzobf-api.onrender.com`.
4. Comprueba que `https://TU-URL/api/status` responda con JSON y `"engine": true`.

El `buildCommand` clona el repositorio público `vo3pal/obscura` durante la compilación e instala sus dependencias. Obscura requiere Python 3.10 o posterior.

## 2. Publicar el frontend en Netlify
1. En Netlify, importa el mismo repositorio.
2. Configura **Base directory** como `frontend`.
3. Configura **Publish directory** como `.` y deja el comando de build vacío.
4. Antes de publicar, edita `frontend/config.js` y reemplaza `https://YOUR-RENDER-SERVICE.onrender.com` por la URL real del backend.
5. Publica el sitio.

## 3. Uso
Abre la URL `*.netlify.app`, pega Luau, elige un modo y pulsa **Obfuscate**. El archivo resultante se descarga como `tryxzobf.lua`.

## Notas
- En planes gratuitos, el backend puede tardar en despertar tras estar inactivo.
- El límite de entrada configurado es 250 KB; el tiempo máximo de ejecución por petición es 100 segundos.
- No pegues claves, contraseñas ni datos privados. El backend recibe el código fuente para procesarlo.
- Prueba el resultado en Roblox Studio. La ofuscación no garantiza que el código sea imposible de recuperar.
- El motor Obscura es un proyecto independiente de terceros, con licencia MIT. Este proyecto no afirma ser oficial ni estar afiliado a su autor.
