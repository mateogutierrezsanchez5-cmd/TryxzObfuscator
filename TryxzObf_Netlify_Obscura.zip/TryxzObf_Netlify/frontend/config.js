// Después de desplegar el backend, pega aquí la URL pública de Render.
window.TRYXZOBF_API = "https://YOUR-RENDER-SERVICE.onrender.com";