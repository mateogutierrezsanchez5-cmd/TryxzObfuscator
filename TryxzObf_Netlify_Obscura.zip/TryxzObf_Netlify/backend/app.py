import os, subprocess, tempfile
from pathlib import Path
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})
app.config["MAX_CONTENT_LENGTH"] = 300 * 1024

BASE = Path(__file__).resolve().parent
ENGINE = BASE / "obscura"
MAIN = ENGINE / "main.py"
HEADER = "--[[ TryxzObf [tryxzobf.lua/obfuscator] ]]"
MODES = {"lightweight", "rename", "native", "vm"}

@app.get("/api/status")
def status():
    return jsonify(ok=True, engine=MAIN.exists(), engine_name="Obscura")

@app.post("/api/obfuscate")
def obfuscate():
    data = request.get_json(silent=True) or {}
    source = data.get("source")
    mode = data.get("mode", "lightweight")
    if not isinstance(source, str) or not source.strip():
        return jsonify(error="El código está vacío."), 400
    if len(source.encode("utf-8")) > 250 * 1024:
        return jsonify(error="El código supera el límite de 250 KB."), 413
    if mode not in MODES:
        return jsonify(error="Modo no válido."), 400
    if not MAIN.exists():
        return jsonify(error="No se encontró el motor Obscura en el servidor."), 503

    with tempfile.TemporaryDirectory() as temp:
        input_path = Path(temp) / "input.luau"
        output_path = Path(temp) / "tryxzobf.lua"
        input_path.write_text(source, encoding="utf-8")
        cmd = ["python", str(MAIN), str(input_path), "--mode", mode, "-o", str(output_path)]
        try:
            proc = subprocess.run(cmd, cwd=ENGINE, capture_output=True, text=True, timeout=100)
        except subprocess.TimeoutExpired:
            return jsonify(error="El procesamiento tardó demasiado. Intenta con un script más pequeño."), 504
        if proc.returncode != 0 or not output_path.exists():
            detail = (proc.stderr or proc.stdout or "Error interno de Obscura")[-1800:]
            return jsonify(error="Obscura no pudo procesar el código.", detail=detail), 422
        output = output_path.read_text(encoding="utf-8", errors="replace")
        if not output.lstrip().startswith(HEADER):
            output = HEADER + "\n" + output
        return jsonify(output=output, filename="tryxzobf.lua")

@app.errorhandler(413)
def too_large(_):
    return jsonify(error="La solicitud es demasiado grande."), 413

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "10000")))
